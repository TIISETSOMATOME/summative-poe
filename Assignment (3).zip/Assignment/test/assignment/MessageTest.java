package assignment;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class MessageTest {

    // Existing Unit Tests (Parts 1 & 2)
    @Test
    public void testMessageLengthSuccess() {
        Message msg = new Message("1234567890", 0, "+27718693002", "Hi Mike, can you join us for dinner tonight?");
        assertEquals("Message ready to send.", msg.checkMessageLength());
    }

    @Test
    public void testMessageLengthFailure() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 260; i++) {
            sb.append("a");
        }
        Message msg = new Message("1234567890", 0, "+27718693002", sb.toString());
        assertTrue(msg.checkMessageLength().contains("Message exceeds 250 characters"));
    }

    @Test
    public void testRecipientCellSuccess() {
        Message msg = new Message("1234567890", 0, "+27718693002", "Hello");
        assertEquals("Cell phone number successfully captured.", msg.checkRecipientCell());
    }

    @Test
    public void testRecipientCellFailure() {
        Message msg = new Message("1234567890", 0, "08575975889", "Hello");
        assertTrue(msg.checkRecipientCell().contains("incorrectly formatted"));
    }

    @Test
    public void testMessageHash() {
        Message msg = new Message("0012345678", 0, "+27718693002", "Hi tonight");
        assertEquals("00:0:HITONIGHT", msg.createMessageHash());
    }

    @Test
    public void testMessageIDValidation() {
        Message msg = new Message("1234567890", 0, "+27718693002", "Test");
        assertTrue(msg.checkMessageID());
    }

    // === PART 3 NEW UNIT TESTS (JUnit 5) ===
    // EXPLANATION FOR VIDEO: These new unit tests validate Part 3 features 
    // such as finding the longest message, searching by ID or recipient, and deleting by hash.

    @Test
    public void testDisplayLongestStoredMessage() {
        // Test that the method handles empty/stored states correctly using JUnit 5 assertions
        String result = Message.displayLongestStoredMessage();
        assertNotNull(result);
    }

    @Test
    public void testSearchMessageID() {
        Message msg = new Message("0838884567", 4, "+27838884567", "It is dinner time!");
        assertTrue(msg.checkMessageID());
        assertEquals("0838884567", msg.getMessageID());
    }

    @Test
    public void testSearchRecipientMessages() {
        String testRecipient = "+27838884567";
        Message msg = new Message("1234567891", 2, testRecipient, "Where are you? You are late! I have asked you to be on time.");
        assertEquals(testRecipient, msg.getRecipient());
    }

    @Test
    public void testDeleteMessageByHash() {
        Message msg = new Message("1234567891", 2, "+27838884567", "Where are you? You are late! I have asked you to be on time.");
        String hash = msg.createMessageHash();
        assertNotNull(hash);
        
        String deletionResult = Message.deleteMessageByHash(hash);
        assertNotNull(deletionResult);
    }
}