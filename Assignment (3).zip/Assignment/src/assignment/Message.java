package assignment;

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;
import org.json.simple.JSONObject;

public class Message {

    // declare Variables
    private String messageID;
    private int messageNumber;
    private String recipient;
    private String message;

    // === PART 3 ADDITION: Static Tracking Lists and Arrays ===
    // EXPLANATION FOR VIDEO: We utilize ArrayLists to dynamically populate and store messages 
    // across Sent, Disregarded, and Stored categories, as well as tracking Hashes and IDs without hardcoding.
    private static ArrayList<Message> sentMessages = new ArrayList<>();
    private static ArrayList<Message> disregardedMessages = new ArrayList<>();
    private static ArrayList<Message> storedMessages = new ArrayList<>();
    private static ArrayList<String> messageHashes = new ArrayList<>();
    private static ArrayList<String> messageIDs = new ArrayList<>();
    private static int totalMessages = 0;

    // Constructor
    public Message(String messageID, int messageNumber, String recipient, String message) {
        this.messageID = messageID;
        this.messageNumber = messageNumber;
        this.recipient = recipient;
        this.message = message;
    }

    // Getters
    public String getMessageID() { return messageID; }
    public int getMessageNumber() { return messageNumber; }
    public String getRecipient() { return recipient; }
    public String getMessage() { return message; }

    // 1. Check Message ID (Must not be more than 10 characters)
    public boolean checkMessageID() {
        return messageID != null && messageID.length() <= 10;
    }

    // 2. Check Recipient Cell
    public String checkRecipientCell() {
        if (recipient != null && recipient.matches("^\\+27[6-8][0-9]{8}$")) {
            return "Cell phone number successfully captured.";
        } else {
            return "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.";
        }
    }

    public boolean isValidRecipientCell() {
        return recipient != null && recipient.matches("^\\+27[6-8][0-9]{8}$");
    }

    // 3. Check Message Length (Max 250 characters)
    public String checkMessageLength() {
        if (message != null && message.length() <= 250) {
            return "Message ready to send.";
        } else {
            int excess = message.length() - 250;
            return "Message exceeds 250 characters by " + excess + "; please reduce the size";
        }
    }

    // 4. Create Message Hash
    public String createMessageHash() {
        String firstTwoNumbers;
        if (messageID != null && messageID.length() >= 2) {
            firstTwoNumbers = messageID.substring(0, 2);
        } else {
            firstTwoNumbers = (messageID != null) ? messageID : "00";
        }

        String firstWord = "";
        String lastWord = "";

        if (message != null && !message.trim().isEmpty()) {
            String cleanMessage = message.trim();
            String[] words = cleanMessage.split("\\s+");
            
            if (words.length > 0) {
                firstWord = words[0].replaceAll("[^a-zA-Z0-9]", "");
                lastWord = words[words.length - 1].replaceAll("[^a-zA-Z0-9]", "");
            }
        }

        return (firstTwoNumbers + ":" + messageNumber + ":" + firstWord + lastWord).toUpperCase();
    }

    // 5. SentMessage Method (Handles User Options: Send, Disregard, Store)
    public String SentMessage(Scanner input) {
        System.out.println("\n--- MESSAGE ACTIONS ---");
        System.out.println("1. Send Message");
        System.out.println("2. Disregard Message");
        System.out.println("3. Store Message to send later");
        System.out.print("Choose an option (1-3): ");
        
        String option = input.nextLine();
        
        switch (option) {
            case "1":
                sentMessages.add(this);
                messageHashes.add(createMessageHash());
                messageIDs.add(messageID);
                totalMessages++;
                storeMessage(); 
                return "Message successfully sent.";
            case "2":
                disregardedMessages.add(this);
                return "Message disregarded.";
            case "3":
                // === PART 3 MODIFICATION: Add to Stored Messages Array ===
                // EXPLANATION FOR VIDEO: When option 3 is selected, the message object is added 
                // to the storedMessages list and its hash/ID are tracked in their respective arrays.
                storedMessages.add(this);
                messageHashes.add(createMessageHash());
                messageIDs.add(messageID);
                storeMessage();
                return "Message successfully stored";
            default:
                return "Invalid option selected.";
        }
    }

    // 6. Store Message in JSON
    public void storeMessage() {
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("messageID", messageID);
        jsonObject.put("messageNumber", messageNumber);
        jsonObject.put("recipient", recipient);
        jsonObject.put("message", message);
        jsonObject.put("messageHash", createMessageHash());
    }

    // 7. Print All Sent Messages
    public static String printMessages() {
        if (sentMessages.isEmpty()) {
            return "No sent messages found.";
        }
        StringBuilder sb = new StringBuilder();
        for (Message m : sentMessages) {
            sb.append("Message ID: ").append(m.messageID).append("\n")
              .append("Message Hash: ").append(m.createMessageHash()).append("\n")
              .append("Recipient: ").append(m.recipient).append("\n")
              .append("Message: ").append(m.message).append("\n\n");
        }
        return sb.toString();
    }

    // 8. Return Total Messages Sent
    public static int returnTotalMessages() {
        return totalMessages;
    }

    // Helper generator for unique 10-digit ID
    public static String generateMessageID() {
        Random rand = new Random();
        long id = 1000000000L + rand.nextInt(900000000);
        return String.valueOf(id);
    }

    // ==========================================
    // === PART 3 REQUIRED METHODS (a through f) ===
    // ==========================================

    // a) Display the sender and recipient of all stored messages
    public static String displayStoredSendersAndRecipients() {
        if (storedMessages.isEmpty()) {
            return "No stored messages available.";
        }
        StringBuilder sb = new StringBuilder();
        for (Message m : storedMessages) {
            sb.append("Sender ID: ").append(m.messageID).append(" | Recipient: ").append(m.recipient).append("\n");
        }
        return sb.toString();
    }

    // b) Display the longest stored message
    public static String displayLongestStoredMessage() {
        if (storedMessages.isEmpty()) {
            return "No stored messages available.";
        }
        Message longest = storedMessages.get(0);
        for (Message m : storedMessages) {
            if (m.message.length() > longest.message.length()) {
                longest = m;
            }
        }
        return "Longest Message:\nRecipient: " + longest.recipient + "\nMessage: " + longest.message + " (Length: " + longest.message.length() + " chars)";
    }

    // c) Search for a message ID and display the corresponding recipient and message
    public static String searchMessageID(String id) {
        for (Message m : storedMessages) {
            if (m.messageID.equals(id)) {
                return "Found Message ID: " + m.messageID + "\nRecipient: " + m.recipient + "\nMessage: " + m.message;
            }
        }
        // Also check sent messages if not found in stored
        for (Message m : sentMessages) {
            if (m.messageID.equals(id)) {
                return "Found Message ID: " + m.messageID + "\nRecipient: " + m.recipient + "\nMessage: " + m.message;
            }
        }
        return "No message found with ID: " + id;
    }

    // d) Search for all the messages stored for a particular recipient
    public static String searchRecipientMessages(String recipientCell) {
        StringBuilder sb = new StringBuilder();
        boolean found = false;
        for (Message m : storedMessages) {
            if (m.recipient.equals(recipientCell)) {
                sb.append("Message: \"").append(m.message).append("\"\n");
                found = true;
            }
        }
        for (Message m : sentMessages) {
            if (m.recipient.equals(recipientCell)) {
                sb.append("Message: \"").append(m.message).append("\"\n");
                found = true;
            }
        }
        if (!found) {
            return "No messages found for recipient: " + recipientCell;
        }
        return sb.toString();
    }

    // e) Delete a message using the message hash
    public static String deleteMessageByHash(String hash) {
        Message toRemove = null;
        for (Message m : storedMessages) {
            if (m.createMessageHash().equalsIgnoreCase(hash)) {
                toRemove = m;
                break;
            }
        }
        if (toRemove != null) {
            storedMessages.remove(toRemove);
            messageHashes.remove(hash);
            return "Message: \"" + toRemove.getMessage() + "\" successfully deleted.";
        }
        return "Message with hash '" + hash + "' could not be found.";
    }

    // f) Display a report that lists the full details of all the stored messages
    public static String displayStoredReport() {
        if (storedMessages.isEmpty()) {
            return "No stored messages to display in report.";
        }
        StringBuilder sb = new StringBuilder();
        for (Message m : storedMessages) {
            sb.append("Message Hash: ").append(m.createMessageHash()).append("\n")
              .append("Recipient: ").append(m.recipient).append("\n")
              .append("Message: ").append(m.message).append("\n")
              .append("----------------------------------\n");
        }
        return sb.toString();
    }
}